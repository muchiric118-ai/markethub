// Package commands implements IMAP commands defined in RFC 3501.
package commands
